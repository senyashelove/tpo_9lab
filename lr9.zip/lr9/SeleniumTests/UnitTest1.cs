using System;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using System.Threading;

namespace SeleniumTests
{
    public class Tests
    {
        private IWebDriver driver;
        private StringBuilder verificationErrors;
        private string baseURL;

        [SetUp]
        public void Setup()
        {
            var options = new ChromeOptions();
            options.BinaryLocation = @"C:\Program Files\Google\Chrome\Application\chrome.exe";
            driver = new ChromeDriver("C:\\webdriver\\chromedriver-win64", options);
            baseURL = "https://5element.by/catalog/377-smartfony";
            verificationErrors = new StringBuilder();
        }

        [TearDown]
        public void TearDownTest()
        {
            try
            {
                driver.Quit();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            Assert.That(verificationErrors.ToString(), Is.EqualTo(""));
        }

        [Test]
        public void Test1()
        {
            driver.Navigate().GoToUrl(baseURL);

            Thread.Sleep(1000);

       
            var products = driver.FindElements(By.CssSelector(".product-item"));

            Random random = new Random();
            int randomIndex = random.Next(products.Count);
            IWebElement randomProduct = products[randomIndex];

            randomProduct.Click();

            Thread.Sleep(1000);

            driver.FindElement(By.CssSelector("button.buy-btn")).Click();

            driver.Navigate().GoToUrl("https://5element.by/cart");

            Thread.Sleep(1000);

            Assert.That(driver.FindElement(By.CssSelector(".mr-3.my-auto")).Text, Is.EqualTo("1 ��."));
        }
    }
}
